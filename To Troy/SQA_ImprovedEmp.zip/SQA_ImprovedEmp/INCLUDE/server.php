<?php
	
	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "sqa_emp2";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
	
	if (isset($_POST['save'])){
		$emp_first_name = $_POST['fname'];
		$emp_middle_name = $_POST['mname'];
		$emp_last_name = $_POST['lname'];
		$emp_birthdate = $_POST['bdate'];
		$emp_mobile_contact = $_POST['contact'];
		$emp_status = $_POST['status'];
		$emp_nationality = $_POST['nationality'];
		$emp_religion = $_POST['religion'];
		$emp_height = $_POST['height'];
		$emp_weight = $_POST['weight'];
		$dep_id = $_POST['dep_id'];
		
		$emp_first_name = ucwords(strtolower($emp_first_name));
		$emp_middle_name = ucwords(strtolower($emp_middle_name));
		$emp_last_name = ucwords(strtolower($emp_last_name));
		$emp_nationality = ucwords(strtolower($emp_nationality));
		$emp_religion = ucwords(strtolower($emp_religion));
		
		$cyear = date('Y');
		$randomNum = rand(10000,99999);
		$fletter = substr($emp_first_name,0,1);
		$mletter = substr($emp_middle_name,0,1);
		$lletter = substr($emp_last_name,0,1);
		
		$emp_id = $cyear.$randomNum.$fletter.$mletter.$lletter;
		
		$emp_age = (date('Y') - date('Y',strtotime($emp_birthdate)));
		
		$query = "INSERT INTO employee_information (emp_id, emp_first_name, emp_last_name, emp_middle_name, emp_age, emp_birthdate,
		emp_mobile_contact, emp_status, emp_nationality, emp_religion, emp_height, emp_weight, dep_id) 
		VALUES ('$emp_id', '$emp_first_name', '$emp_last_name', '$emp_middle_name', '$emp_age', '$emp_birthdate', '$emp_mobile_contact', 
		'$emp_status', '$emp_nationality', '$emp_religion', '$emp_height', '$emp_weight', '$dep_id');";
		mysqli_query($conn, $query);
		header("Location: ../addBenefits.php?new=$emp_id");
	}
	
	if (isset($_POST['edit'])){
		$emp_first_name = mysqli_real_escape_string($conn, $_POST['fname']);
		$emp_middle_name = mysqli_real_escape_string($conn, $_POST['mname']);
		$emp_last_name = mysqli_real_escape_string($conn, $_POST['lname']);
		$emp_age = mysqli_real_escape_string($conn, $_POST['age']);
		$emp_birthdate = mysqli_real_escape_string($conn, $_POST['bdate']);
		$emp_mobile_contact = mysqli_real_escape_string($conn, $_POST['contact']);
		$emp_status = mysqli_real_escape_string($conn, $_POST['status']);
		$emp_nationality = mysqli_real_escape_string($conn, $_POST['nationality']);
		$emp_religion = mysqli_real_escape_string($conn, $_POST['religion']);
		$emp_height = mysqli_real_escape_string($conn, $_POST['height']);
		$emp_weight = mysqli_real_escape_string($conn, $_POST['weight']);
		$emp_id = mysqli_real_escape_string($conn, $_POST['emp_id']);
		$dep_id = mysqli_real_escape_string($conn, $_POST['dep_id']);
		
		$emp_first_name = ucwords(strtolower($emp_first_name));
		$emp_middle_name = ucwords(strtolower($emp_middle_name));
		$emp_last_name = ucwords(strtolower($emp_last_name));
		$emp_nationality = ucwords(strtolower($emp_nationality));
		$emp_religion = ucwords(strtolower($emp_religion));
		
		$emp_age = (date('Y') - date('Y',strtotime($emp_birthdate)));
		
		mysqli_query($conn, "UPDATE employee_information SET emp_first_name = '$emp_first_name', emp_last_name = '$emp_last_name', 
		emp_middle_name = '$emp_middle_name', emp_age = '$emp_age', emp_birthdate = '$emp_birthdate', emp_mobile_contact = '$emp_mobile_contact', 
		emp_status = '$emp_status', emp_nationality = '$emp_nationality', emp_religion = '$emp_religion', emp_height = '$emp_height',
		emp_weight = '$emp_weight', dep_id = '$dep_id' WHERE emp_id = '$emp_id'");
		header("Location: ../editBenefits.php?edit=$emp_id");
	}
	
	if (isset($_GET['del'])){
		$emp_id = $_GET['del'];
		mysqli_query($conn, "DELETE FROM employee_information WHERE emp_id= '$emp_id'");
		mysqli_query($conn, "DELETE FROM employees_benefits WHERE emp_id= '$emp_id'");
		header('Location: ../employeeRecords.php');
	}
	
	
	
	if (isset($_POST['saveDep'])){
		$dep_name = $_POST['dep_name'];
		$position = $_POST['position'];
		$basic_salary = $_POST['basic_salary'];
		
		$randomNum = rand(1000,9999);
		$fletter = substr($dep_name,0,1);
		$sletter = substr($position,0,1);
		
		$dep_id = $fletter.$sletter.$randomNum;
		
		$query = "INSERT INTO department (dep_id, dep_name, position, basic_salary) 
		VALUES ('$dep_id', '$dep_name', '$position', '$basic_salary');";
		mysqli_query($conn, $query);
		header('Location: ../departmentRecords.php'); //redirect to index page after inserting
	}
	
	if (isset($_POST['editDep'])){
		$dep_id = mysqli_real_escape_string($conn, $_POST['dep_id']);
		$dep_name = mysqli_real_escape_string($conn, $_POST['dep_name']);
		$position =  mysqli_real_escape_string($conn, $_POST['position']);
		$basic_salary = mysqli_real_escape_string($conn, $_POST['basic_salary']);
		
		mysqli_query($conn, "UPDATE department SET dep_name = '$dep_name', position = '$position',
		basic_salary = '$basic_salary' WHERE dep_id = '$dep_id'");
		header('Location: ../departmentRecords.php');
	}
	
	if (isset($_GET['delDep'])){
		$dep_id = $_GET['delDep'];
		mysqli_query($conn, "DELETE FROM department WHERE dep_id= '$dep_id'");
		header('Location: ../departmentRecords.php');
	}
	
	
	if (isset($_POST['saveBen'])){
		$emp_id = $_POST['emp_id'];
		$emp_TIN = $_POST['emp_TIN'];
		$emp_SSS = $_POST['emp_SSS'];
		$emp_PAGIBIG = $_POST['emp_PAGIBIG'];
		$emp_PhilHealth = $_POST['emp_PhilHealth'];
		$emp_TaxCode = $_POST['emp_TaxCode'];
		
		$query = "INSERT INTO employees_benefits (emp_id, emp_TIN, emp_SSS, emp_PAGIBIG, emp_PhilHealth, emp_TaxCode) 
		VALUES ('$emp_id', '$emp_TIN', '$emp_SSS', '$emp_PAGIBIG', '$emp_PhilHealth', '$emp_TaxCode');";
		mysqli_query($conn, $query);
		header("Location: ../employeeRecords.php");
	}
	
	if (isset($_POST['editBen'])){
		$emp_id = mysqli_real_escape_string($conn, $_POST['emp_id']);
		$emp_TIN = mysqli_real_escape_string($conn, $_POST['emp_TIN']);
		$emp_SSS = mysqli_real_escape_string($conn, $_POST['emp_SSS']);
		$emp_PAGIBIG = mysqli_real_escape_string($conn, $_POST['emp_PAGIBIG']);
		$emp_PhilHealth = mysqli_real_escape_string($conn, $_POST['emp_PhilHealth']);
		$emp_TaxCode = mysqli_real_escape_string($conn, $_POST['emp_TaxCode']);
		
		mysqli_query($conn, "UPDATE employees_benefits SET emp_TIN = '$emp_TIN', emp_SSS = '$emp_SSS', emp_PAGIBIG = '$emp_PAGIBIG', emp_PhilHealth = '$emp_PhilHealth',
		emp_TaxCode = '$emp_TaxCode' WHERE emp_id = '$emp_id'");
		header("Location: ../employeeRecords.php");
	}
	
	
	$resultsDep = mysqli_query($conn, "SELECT * FROM department");
	
	
	$results = mysqli_query($conn, "SELECT employee_information.*, department.*, employees_benefits.* FROM employee_information RIGHT JOIN department ON 
		employee_information.dep_id = department.dep_id RIGHT JOIN employees_benefits ON employee_information.emp_id = employees_benefits.emp_id");
	
	$selectOptions = mysqli_query($conn, "SELECT * FROM department");
?>