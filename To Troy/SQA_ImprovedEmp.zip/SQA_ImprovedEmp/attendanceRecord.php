<?php include('attendanceModule.php');

	if(isset($_POST['submit'])){
		$emp_id = $_POST['search'];
		$date1 = $_POST['date1'];
		$date2 = $_POST['date2'];
		
		if(empty($emp_id)==FALSE && (empty($date1) && empty($date2)))
			$Query = "SELECT * FROM attendance_log WHERE emp_id = '$emp_id'";
		
		if(empty($emp_id) && (empty($date1)==FALSE && empty($date2)==FALSE))
			$Query = "SELECT * FROM attendance_log WHERE date_of_attendance BETWEEN '$date1' AND '$date2'";
		
		if(empty($emp_id)==FALSE && (empty($date1)==FALSE && empty($date2)==FALSE))
			$Query = "SELECT * FROM attendance_log WHERE emp_id = '$emp_id' AND date_of_attendance BETWEEN '$date1' AND '$date2'";
		
		$results = mysqli_query($conn, $Query);
	}
	$rowNumQuery = "SELECT count(logID) AS total FROM attendance_log";
	$rowNumResult = mysqli_query($conn,$rowNumQuery);
	$value = mysqli_fetch_array($rowNumResult);
	$num_of_rows = $value['total'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance Record</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header" align=center>
		<label>ATTENDANCE RECORD</label>
	</div>
	
	<table>
		<thead>
			<tr>
				<th>Date</th>
				<th>Emp<br>ID</th>
				<th>Time<br>In</th>
				<th>Break<br>Out</th>
				<th>Break<br>In</th>
				<th>Time<br>Out</th>
				<th>Hours<br>Rendered</th>
				<th>Late</th> 
				<th>Late<br>Deduction</th>
				<th>Undertime</th>
				<th>Overtime</th>
				<th>Total Hours<br>Rendered</th>
			</tr>
		</thead>
		<tbody>
			<?php
			if($num_of_rows > 0){
			while ($row = mysqli_fetch_array ($results)){ ?>
				<tr>
					<td><?php echo $row['date_of_attendance']; ?></td>
					<td><?php echo $row['emp_id']; ?></td>
					<td><?php echo date('h:i a',strtotime($row['time_in'])); ?></td>
					<td><?php echo date('h:i a',strtotime($row['break_out'])); ?></td>
					<td><?php echo date('h:i a',strtotime($row['break_in'])); ?></td>
					<td><?php echo date('h:i a',strtotime($row['time_out'])); ?></td>
					<td><?php echo $row['hours_rendered'] .' hrs'; ?></td>
					<td><?php echo $row['late'].' mins'; ?></td>
					<td><?php echo $row['late_deduction']; ?></td>
					<td><?php echo $row['undertime'].' hrs'; ?></td>
					<td><?php echo $row['overtime'].' hrs'; ?></td>
					<td><?php echo $row['total_hours_rendered'].' hrs'; ?></td>
				</tr>
			<?php }}else{?>
				<tr><td align=center colspan=12><?php echo "No Record Availble"; }?></td></tr>
			
		</tbody>
	</table>
	
	<form action="attendanceRecord.php" method="POST" class="form">
		<div align=center>
			<div class="input-group">
				<label>Search Emp ID:</label>
				<input type="text" name="search">
			</div>
			<hr style="width:90%;">
			<label style="margin-left:-75%">Search Dates:</label>
			<div class="input-group" style="margin-left:-5%">
				<label>&nbsp;from </label>
				<input type="date" name="date1" style="margin-bottom:5px">
				<br>
				<label>until </label>
				<input type="date" name="date2">
			</div>
			<input type="submit" name="submit" class="btn">
		</div>
	</form>
	
</body>
</html>