<?php include('attendanceModule.php');
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$result = mysqli_query($conn,"SELECT * FROM attendance_log WHERE logID = '$id'");
		$row = mysqli_fetch_array($result);
		$id = $row['logID'];
		$emp_id = $row['emp_id'];
		$time_in = $row['time_in'];
		$break_out = $row['break_out'];
		$break_in = $row['break_in'];
		$time_out = $row['time_out'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance Log</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		if (isset($_GET['error'])){
			if ($_GET['error']==1){ 
				echo "<p class='msg'>Please wait after 4 hours before logging a break out.</p>";
			}
			if ($_GET['error']==2){ 
				echo "<p class='msg'>Please input your ID.</p>";
			}
			if ($_GET['error']==3){ 
				echo "<p class='msg'>Invalid employee ID.</p>";
			}
		}
	?>
	<div class="header" align=center>
		<label>ATTENDANCE LOG MODULE</label>
	</div>
	
	<div align=center>
	
	<form action="attendanceModule.php" class="log" method="POST">	
		<h3>Employee ID:</h3>	
		<div class="input-group" align=center>
			<input type="text" name="emp_id" value="<?php if(isset($_GET['id'])){echo $emp_id;}?>">
		</div>
		<input type="submit" name="submitID" class="btn" value="Log-In">
		
		<div align=center>
		<?php 
		if((isset($_GET['id']))&&(isset($emp_id))&&($time_out!='00:00:00')){
	echo "<p>You have already finished a day's work.<br>Thank you very much for your hard work!</p>";}
		
		if((isset($_GET['id']))&&(isset($emp_id))&&($time_out=='00:00:00')&&($break_in!='00:00:00')){
	echo "
		<h1>Time Out:</>
		<input type='hidden' name='id' value='$id'>
		<input class='log-btn' type='submit' name='timeOutSubmit' value='Log Time'>";}
		
		 if((isset($_GET['id']))&&(isset($emp_id))&&($break_in=='00:00:00')&&($break_out!='00:00:00')){
	echo "
		<h3>Break In:</h3>
		<input type='hidden' name='id' value='$id'>
		<input class='log-btn' type='submit' name='breakInSubmit' value='Log Time'>";}
		
		if((isset($_GET['id']))&&(isset($emp_id))&&($break_out=='00:00:00')&&($time_in!='00:00:00')){
	echo "
		<h3>Break Out:</h3>
		<input type='hidden' name='id' value='$id'>
		<input class='log-btn' type='submit' name='breakOutSubmit' value='Log Time'>";}
		
		if((isset($_GET['id']))&&(isset($emp_id))&&($time_in=='00:00:00')){
	echo"
		<h3>Time In:</h3>
		<input type='hidden' name='id' value='$id'>
		<input class='log-btn' type='submit' name='timeInSubmit' value='Log Time'>";}?>
		</div>
	</form>
	</div>
	
	
</body>
</html>