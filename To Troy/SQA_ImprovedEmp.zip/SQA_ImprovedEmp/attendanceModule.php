<?php 

	date_default_timezone_set('Asia/Manila');
	
	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "sqa_emp2";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
	
	if(isset($_POST['submitID'])){
		$emp_id = $_POST['emp_id'];
		$date_of_attendance = date('Y-m-d');
		
		if(empty($emp_id)){
			header("Location: attendance.php?error=2");
		}
		elseif(isset($emp_id)){
			
			$result = mysqli_query($conn, "SELECT * FROM attendance_log WhERE emp_id = '$emp_id' AND date_of_attendance = '$date_of_attendance'");
			$rec = mysqli_fetch_array($result);
			$emp_id_db = $rec['emp_id'];
			$date_of_attendance_db = $rec['date_of_attendance'];
			$id = $rec['logID'];
			
			if($emp_id == $emp_id_db && $date_of_attendance == $date_of_attendance_db){
				header("Location: attendance.php?id=$id");
			}
			else{
				$query = "SELECT * FROM employee_information WHERE emp_id = '$emp_id'";
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_array($result);
				$ID = $row['emp_id'];
				if($ID == $emp_id){
					mysqli_query($conn,"INSERT INTO attendance_log (logID, emp_id, time_in, time_out, break_in, break_out, date_of_attendance, hours_rendered, late, late_deduction, undertime, overtime, total_hours_rendered)
					VALUES ('','$emp_id','','','','','$date_of_attendance','','','','','','')");
					
					$result = mysqli_query($conn, "SELECT * FROM attendance_log WhERE emp_id = '$emp_id' AND date_of_attendance = '$date_of_attendance'");
					$rec = mysqli_fetch_array($result);
					$id = $rec['logID'];
					
					header("Location: attendance.php?id=$id");
				}
				else{
					header("Location: attendance.php?error=3");
				}
				
			}
		}
		
	}
	
	if(isset($_POST['timeInSubmit'])){
		$time_in = date('H:i');
		$id = $_POST['id'];
		mysqli_query($conn, "UPDATE attendance_log SET time_in = '$time_in' WhERE logID='$id'");
		
		header("Location: attendance.php");
	}
	
	if(isset($_POST['breakOutSubmit'])){
		$break_out = date('H:i');
		$id = $_POST['id'];
		$emp_id = $_POST['emp_id'];
		$date_of_attendance = date('Y-m-d');
		
		$result = mysqli_query($conn, "SELECT * FROM attendance_log WhERE emp_id = '$emp_id' AND date_of_attendance = '$date_of_attendance'");
		$rec = mysqli_fetch_array($result);
		$time_in = $rec['time_in'];
		
		//$time_compare = date('H:i', strtotime('+ 4 hours',  strtotime($time_in)));
		
		if (((strtotime($break_out) - strtotime($time_in))/60/60) <= 4.00){
			header("Location: attendance.php?error=1");
		}
		else{
			mysqli_query($conn, "UPDATE attendance_log SET break_out = '$break_out' WhERE logID='$id'");
			header("Location: attendance.php");
			
		}
		
	}
	
	if(isset($_POST['breakInSubmit'])){
		$break_in = date('H:i');
		$id = $_POST['id'];
		
		/*$emp_id = $_POST['emp_id'];
		$date_of_attendance = date('Y-m-d');
		
		$result = mysqli_query($conn, "SELECT * FROM attendance_log WhERE emp_id = '$emp_id' AND date_of_attendance = '$date_of_attendance'");
		$rec = mysqli_fetch_array($result);
		$break_out = $rec['break_out'];
		
		if (((strtotime($break_out) - strtotime($time_in))/60/60) <= 4.00){
			header("Location: attendance.php?error=1");
		}
		else{
			mysqli_query($conn, "UPDATE attendance_log SET break_in = '$break_in' WhERE logID='$id'");
			header("Location: attendance.php");
			
		}*/
		mysqli_query($conn, "UPDATE attendance_log SET break_in = '$break_in' WhERE logID='$id'");
		header("Location: attendance.php");
	}
	
	if(isset($_POST['timeOutSubmit'])){
		$id = $_POST['id'];
		$time_out = date('H:i');

		$date_of_attendance = date('Y-m-d');
		
		mysqli_query($conn, "UPDATE attendance_log SET time_out = '$time_out' WhERE logID='$id'");
		
		$Result = mysqli_query($conn, "SELECT * FROM attendance_log WhERE logID = '$id'");
		$record = mysqli_fetch_array($Result);
		$emp_id = $record['emp_id'];
		$time_in = strtotime($record['time_in']);
		$break_out = strtotime($record['break_out']);
		$break_in = strtotime($record['break_in']);
		$time_out = strtotime($record['time_out']);
		
		
		
		$hours_rendered = (($time_out - $time_in) - ($break_in - $break_out))/60 /60;
		
		$late = ($break_in - $break_out)/60-60;
		
		if ($late >= 15){
			$late_deduct = 1;
		}
		else{
			$late_deduct=0;
			if($late<=0){
				$late = 0;
			}
		}
		
		if ($hours_rendered == 8){
			$undertime = 0;
			$overtime = 0;
		}
		elseif ($hours_rendered < 8){
			$undertime = 8 - $hours_rendered;
			$overtime = 0;
		}
		elseif ($hours_rendered > 8){
			$undertime = 0;
			$overtime = $hours_rendered - 8;
			$hours_rendered = 8;
		}
		
		$total_hours_rendered = $hours_rendered + $overtime - $late_deduct;
		
		$time_in = date('H:i',$time_in);
		$break_out = date('H:i',$break_out);
		$break_in = date('H:i',$break_in);
		$time_out = date('H:i',$time_out);
		
		mysqli_query($conn, "UPDATE attendance_log SET emp_id = '$emp_id', time_in = '$time_in', time_out = '$time_out', 
		break_in = '$break_in', break_out = '$break_out', date_of_attendance = '$date_of_attendance', hours_rendered = '$hours_rendered', 
		late = '$late', late_deduction = '$late_deduct', undertime = '$undertime', overtime = '$overtime', total_hours_rendered = '$total_hours_rendered' WhERE logID='$id'");
		
		header("Location: attendance.php");
	}

	$results = mysqli_query($conn, "SELECT * FROM attendance_log");
?>